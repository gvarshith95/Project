SubSentry Streamlit MVP (demo)

Run locally:
1. python -m pip install -r requirements.txt
2. streamlit run app.py

This demo uses session state only (no persistent DB). For deployment, push to Streamlit Community Cloud or Railway and use a simple secret for auth.
